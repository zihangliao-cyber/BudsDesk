BudsDesk v0.1.0 preview - Windows x64

渝水龙出品
Copyright © 2026 渝水龙
https://github.com/zihangliao-cyber/BudsDesk

Pair and connect Xiaomi Buds 5 Pro in Windows Bluetooth settings.
Run BudsDesk.exe, select the earbuds, and click Connect.

Supports Off / ANC / Transparency, tray menu and global shortcuts.
Ctrl+Alt+N: cycle modes. Ctrl+Alt+T: transparency.
Exit using the tray context menu.

Adaptive ANC, battery, EQ and gestures are not implemented in v0.1.0.
Requires .NET Framework 4.8. No additional runtime installation on a
Windows system that already has .NET Framework 4.8.

This is an independent, unsigned preview application.
MIT License: see LICENSE.
